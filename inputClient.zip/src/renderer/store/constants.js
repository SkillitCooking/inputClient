'use strict';

const timeout = 500;

exports.TIMEOUT = timeout;